import SearchOrganizations from "./components/organizations/SearchOrganizations";

function App() {
  return <SearchOrganizations />;
}

export default App;
